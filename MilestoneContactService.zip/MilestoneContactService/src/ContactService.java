import java.util.*;
public class ContactService{
	private ArrayList<Contact> contact;
	public ContactService() {
		listOfContacts = new ArrayList<>();
	}
	
	public boolean addContact(Contact contact) {
		boolean contactExist = false;
		//change the bool if contact is found 
		for(Contact l:listOfContacts) {
			if(l.equals(contact)) {
				contactExist = true;
			}
		}
		
		//if contactExist false then add else return false 
		if(!contactExist) {
			listOfContacts.add(contact);
			return true;
		}
		else {
			return false;
		}
	}
	

	public boolean deleteContact(String contactID) {
		//look for the contact if found then remove it 
		for(Contact l:listOfContacts) {
			if(l.getContactID().equals(contactID)) {
				listOfContacts.remove(l);
				return true;
			}
		}
		return false;
	}
	
	
	//look for the contact if found then update it with new setters
	public boolean updateContact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
		for(Contact l:listOfContacts) {
			if(l.getContactID().equals(contactID)) {
				
				if(!firstName.equals("") && !(firstName.length() > 10)) {
					l.setFirstName(firstName);
				}
				
				if(!lastName.equals("") && !(lastName.length() > 10)) {
					l.setLastName(lastName);
				}

				if(!phoneNumber.equals("") && !(phoneNumber.length() > 10)) {
					l.setPhoneNumber(phoneNumber);
				}

				if(!address.equals("") && !(address.length() > 30)) {
					l.setAddress(address);
				}
				return true;
			} 
		} 
		return false;
	} 
}