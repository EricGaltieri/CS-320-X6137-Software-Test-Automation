import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {
/*
 * 
 */
	@Test
	void testContactIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() ->{
			new Contact("1234567890000000000","Eric","Galtieri","1234567890","1600 Pennsylvania Avenue");
		});
	}
	
	@Test
	void testContactIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() ->{
			new Contact(null,"Eric","Galtieri","1234567890","1600 Pennsylvania Avenue");
		});
	}
		
	
	
	//test firstName
	@Test
	void testFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() ->{
			new Contact("123456789","Ericccccccc","Galtieri","1234567890","1600 Pennsylvania Avenue");
		});
	}
	@Test
	void testFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() ->{
			new Contact("123456789",null,"Galtieri","1234567890","1600 Pennsylvania Avenue");
		});
	}
	
	
	
//test lastName
	@Test
	void testLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() ->{
			new Contact("123456789","Eric","Galtieriiii","1234567890","1600 Pennsylvania Avenue");
		});
	}
	@Test
	void testLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() ->{
			new Contact("123456789","Eric",null,"1234567890","1600 Pennsylvania Avenue");
		});
	}
	
	
//test phoneNumber
	@Test
	void testPhoneNumberTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() ->{
			new Contact("123456789","Eric","Galtieri","12345678900","1600 Pennsylvania Avenue");
		});
	}
	@Test
	void testPhoneNumberNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() ->{
			new Contact("123456789","Eric","Galtieri",null,"1600 Pennsylvania Avenue");
		});
	}
	
	
	
//test address
	@Test
	void testAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() ->{
			new Contact("123456789","Eric","Galtieri","1234567890","1600 Pennsylvania Avenue NW Washington, D.C.");
		});
	}
	@Test
	void testAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() ->{
			new Contact("123456789","Eric","Galtieri","1234567890",null);
		});
	}
}