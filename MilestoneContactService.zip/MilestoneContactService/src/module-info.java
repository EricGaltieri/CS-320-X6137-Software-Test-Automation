/**
 * 
 */
/**
 * @author eric
 *
 */
module MilestoneContactService {
}