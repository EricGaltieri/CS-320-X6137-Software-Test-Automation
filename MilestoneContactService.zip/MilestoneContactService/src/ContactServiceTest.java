import static org.junit.jupiter.api.Assertions.*;
import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.Test;
class ContactServiceTest {
	
	/*
	 * 
	 */
	// test variant should be phone number, first name, last name, phone number, address
	 @Test
	 void testAdd() {
		 ContactService cs = new ContactService();
		 
		 Contact cs1 = new Contact("123456789","Eric","Galtieri","1234567890","1600 Pennsylvania Avenue");
		 assertEquals(true, cs.addContact(cs1));
	 }
	 
	@Test
	void testDelete() {
		 ContactService cs = new ContactService();
		 Contact cs1 = new Contact("123456789","Eric","Galtieri","1234567890","1600 Pennsylvania Avenue");
		 Contact cs2 = new Contact("123456788","John","Smith","0987654321","123 West Nowhere");
		 Contact cs3 = new Contact("123456787","Jill","Smith","7418529630","123 West Nowhere");
		 Contact cs4 = new Contact("123456786","Easter","Island","9632587410","123 East Nowhere");
		 Contact cs5 = new Contact("123456785","Isa","Island","0251478632","123 East Nowhere");
		 
		 assertEquals(true, cs.deleteContact("123456787"));
		 assertEquals(false,cs.deleteContact("123456786"));
		 assertEquals(false,cs.deleteContact("123456785"));
		 }
		 
	@Test
	void testUpdate() {
		 ContactService cs = new ContactService();
		 Contact cs1 = new Contact("123456789","Eric","Galtieri","1234567890","1600 Pennsylvania Avenue");
		 Contact cs2 = new Contact("123456788","John","Smith","0987654321","123 West Nowhere");
		 Contact cs3 = new Contact("123456787","Jill","Smith","7418529630","123 West Nowhere");
		 Contact cs4 = new Contact("123456786","Easter","Island","9632587410","123 East Nowhere");
		 Contact cs5 = new Contact("123456785","Isa","Island","0251478632","123 East Nowhere");
		 
		 cs.addContact(cs1);
		 cs.addContact(cs2);
		 cs.addContact(cs3);
		 cs.addContact(cs4);
		 cs.addContact(cs5);
		 
		 Contact cs4 = new Contact("123456786","Easter","Island","9632587410","123 East Nowhere");
		 Contact cs5 = new Contact("123456785","Isa","Island","0251478632","123 East Nowhere");
	}
}